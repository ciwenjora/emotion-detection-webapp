"""
model.py
---------------------------------------
Downloads a pretrained CNN model for emotion detection
(based on the FER-2013 dataset) and saves it as
'default_emotion_model.h5' in the project folder.
---------------------------------------
"""

import os
import urllib.request

ROOT = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(ROOT, 'default_emotion_model.h5')

def download_model():
    """Download a pretrained FER2013 emotion model."""
    url = 'https://github.com/atulapra/Emotion-detection/raw/master/model.h5'
    print("Starting download of pretrained emotion model...")
    urllib.request.urlretrieve(url, MODEL_PATH)
    print("✅ Download complete! Model saved at:", MODEL_PATH)

if __name__ == '__main__':
    if not os.path.exists(MODEL_PATH):
        try:
            download_model()
        except Exception as e:
            print("❌ Download failed:", e)
            print("Please ensure you have an internet connection.")
    else:
        print("✅ Model already exists at", MODEL_PATH)
