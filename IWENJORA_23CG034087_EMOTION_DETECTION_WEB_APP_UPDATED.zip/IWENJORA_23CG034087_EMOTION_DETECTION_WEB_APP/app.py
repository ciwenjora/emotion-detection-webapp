from flask import Flask, render_template, request, redirect, url_for
import os
import sqlite3
from datetime import datetime
import cv2
import numpy as np
import random

try:
    from tensorflow.keras.models import load_model
    TF_AVAILABLE = True
except Exception:
    TF_AVAILABLE = False

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(APP_ROOT, 'static')
MODEL_PATH = os.path.join(APP_ROOT, 'default_emotion_model.h5')

EMOTIONS = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = STATIC_DIR

model = None
if TF_AVAILABLE:
    try:
        model = load_model(MODEL_PATH)
        print('Model loaded successfully.')
    except Exception as e:
        print('TensorFlow available but failed to load model:', e)
        model = None
else:
    print('TensorFlow not available in this environment. Using dummy predictor.')

def init_db():
    conn = sqlite3.connect(os.path.join(APP_ROOT, 'emotion_detection.db'))
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    image_path TEXT,
                    emotion TEXT,
                    timestamp TEXT
                )''')
    conn.commit()
    conn.close()

def dummy_predict(img_path):
    return random.choice(EMOTIONS)

def preprocess_image_for_model(img_path):
    img = cv2.imread(img_path)
    if img is None:
        return None
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    resized = cv2.resize(gray, (48,48))
    normalized = resized.astype('float32')/255.0
    reshaped = normalized.reshape(1,48,48,1)
    return reshaped

@app.route('/', methods=['GET','POST'])
def index():
    init_db()
    emotion = None
    image_url = None
    if request.method == 'POST':
        if 'image' in request.files:
            file = request.files['image']
            if file.filename == '':
                return redirect(request.url)
            filename = datetime.now().strftime('%Y%m%d%H%M%S_') + file.filename.replace(' ','_')
            save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(save_path)

            if model is not None:
                x = preprocess_image_for_model(save_path)
                if x is not None:
                    pred = model.predict(x)
                    emotion = EMOTIONS[int(np.argmax(pred))]
                else:
                    emotion = dummy_predict(save_path)
            else:
                emotion = dummy_predict(save_path)

            conn = sqlite3.connect(os.path.join(APP_ROOT, 'emotion_detection.db'))
            c = conn.cursor()
            c.execute("INSERT INTO users (name, image_path, emotion, timestamp) VALUES (?,?,?,?)",
                      ('Guest', save_path, emotion, datetime.now().isoformat()))
            conn.commit()
            conn.close()

            image_url = os.path.join('static', filename)

    return render_template('index.html', emotion=emotion, image_url=image_url)

@app.route('/capture', methods=['GET'])
def capture():
    init_db()
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        return "Could not open webcam. If running on a remote server, webcam capture is not available."
    ret, frame = cap.read()
    cap.release()
    if not ret:
        return "Failed to capture image from camera."
    filename = datetime.now().strftime('%Y%m%d%H%M%S_capture.jpg')
    save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    cv2.imwrite(save_path, frame)

    if model is not None:
        x = preprocess_image_for_model(save_path)
        if x is not None:
            pred = model.predict(x)
            emotion = EMOTIONS[int(np.argmax(pred))]
        else:
            emotion = dummy_predict(save_path)
    else:
        emotion = dummy_predict(save_path)

    conn = sqlite3.connect(os.path.join(APP_ROOT, 'emotion_detection.db'))
    c = conn.cursor()
    c.execute("INSERT INTO users (name, image_path, emotion, timestamp) VALUES (?,?,?,?)",
              ('Guest', save_path, emotion, datetime.now().isoformat()))
    conn.commit()
    conn.close()

    image_url = os.path.join('static', filename)
    return render_template('index.html', emotion=emotion, image_url=image_url)

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
